package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@SpringBootApplication

public class FirstDemoBoot3Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(FirstDemoBoot3Application.class, args);
	}
	
	@Autowired
	EmployeeRepository repository;


	@Override
	public void run(String... args)throws Exception{
	this.repository.save(new Employee("manjula1997b@gmail.com","06","Manjula","30000"));
	this.repository.save(new Employee("apurva1996b@gmail.com","14","Apurva","30000"));
	this.repository.save(new Employee("sinchana1998b@gmail.com","08","Sinchana","30000"));
	this.repository.save(new Employee("rakshitha1995b@gmail.com","07","Rakshitha","30000"));

}
}